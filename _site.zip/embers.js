/* Cherry Sage — floating amber embers on dark sections (warm, subtle) */
(function(){
  if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var secs=[].slice.call(document.querySelectorAll('.section-dark'));
  secs.forEach(function(sec){
    if(getComputedStyle(sec).position==='static') sec.style.position='relative';
    var c=document.createElement('canvas'); c.className='embers-canvas'; c.setAttribute('aria-hidden','true');
    sec.insertBefore(c, sec.firstChild);
    var ctx=c.getContext('2d'), es=[], W=0,H=0, DPR=Math.min(window.devicePixelRatio||1,2), raf;
    function spawn(seed){ return {x:Math.random()*W, y:seed?Math.random()*H:H+Math.random()*30, r:Math.random()*1.8+0.7,
      vy:-(Math.random()*0.45+0.18), vx:(Math.random()-0.5)*0.22, life:seed?Math.random()*200:0, max:Math.random()*240+170}; }
    function size(){ W=sec.clientWidth; H=sec.clientHeight; c.width=W*DPR; c.height=H*DPR; ctx.setTransform(DPR,0,0,DPR,0,0); }
    function init(){ size(); var N=Math.max(10,Math.min(28,Math.round(W/58))); es=[]; for(var i=0;i<N;i++) es.push(spawn(true)); }
    function tick(){
      ctx.clearRect(0,0,W,H);
      for(var i=0;i<es.length;i++){ var e=es[i];
        e.x+=e.vx; e.y+=e.vy; e.vx+=(Math.random()-0.5)*0.02; e.life++;
        var a=Math.sin(Math.min(e.life/e.max,1)*Math.PI)*0.65;
        if(e.y<-12 || e.life>e.max){ es[i]=spawn(false); continue; }
        ctx.beginPath(); ctx.arc(e.x,e.y,e.r,0,6.2832);
        ctx.fillStyle='rgba(233,173,74,'+a.toFixed(3)+')';
        ctx.shadowBlur=9; ctx.shadowColor='rgba(226,140,46,'+(a*0.85).toFixed(3)+')';
        ctx.fill();
      }
      ctx.shadowBlur=0; raf=requestAnimationFrame(tick);
    }
    init(); tick();
    var t; window.addEventListener('resize',function(){ clearTimeout(t); t=setTimeout(init,220); });
  });
})();
