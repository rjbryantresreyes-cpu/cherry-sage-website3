/* Cherry Sage — Free Tarot Card Pull (for reflection only) */
(function(){
  var DECK=[
    {n:"The Fool",g:"✦",k:"New beginnings · a leap of faith",r:"A fresh chapter is opening. Trust the first step even before you can see the whole staircase."},
    {n:"The Magician",g:"✷",k:"Power · manifestation",r:"You already have what you need. This is a moment to act, not to wait."},
    {n:"The High Priestess",g:"☾",k:"Intuition · inner knowing",r:"The answer is quieter than the noise around it. Listen to what you already sense."},
    {n:"The Empress",g:"❀",k:"Nurturing · abundance",r:"Tend to what you love and it will grow. Softness is a strength here, not a weakness."},
    {n:"The Emperor",g:"◆",k:"Structure · stability",r:"A little order brings a lot of peace. Build the frame, and the rest can settle into it."},
    {n:"The Hierophant",g:"⌂",k:"Tradition · guidance",r:"There is wisdom in asking for help. The path you seek has been walked before."},
    {n:"The Lovers",g:"♡",k:"Connection · a choice",r:"A real choice of the heart is near. Choose from love, not from fear of loss."},
    {n:"The Chariot",g:"➤",k:"Willpower · momentum",r:"Hold your direction. You are closer than the doubt is telling you."},
    {n:"Strength",g:"∞",k:"Courage · gentle power",r:"You are stronger than the thing you are afraid of. Meet it with calm, not force."},
    {n:"The Hermit",g:"✦",k:"Reflection · wisdom",r:"A pause is not a step backward. Time alone is showing you something worth knowing."},
    {n:"Wheel of Fortune",g:"◍",k:"Cycles · a turning point",r:"Things are moving again. What felt stuck is beginning to turn in your favor."},
    {n:"Justice",g:"⚖",k:"Truth · balance",r:"Be honest with yourself first, and the right path becomes clear. Fairness finds you."},
    {n:"The Hanged Man",g:"⸙",k:"Surrender · new perspective",r:"Seeing this differently changes everything. Let go of the grip, just a little."},
    {n:"Death",g:"❖",k:"Transformation · rebirth",r:"An ending is making room for who you are becoming. This is renewal, not loss."},
    {n:"Temperance",g:"⚗",k:"Balance · healing",r:"Gentle and steady wins here. Blend the pieces slowly and let things heal."},
    {n:"The Star",g:"★",k:"Hope · clarity",r:"After a hard stretch, a little light returns. Keep your face toward it."},
    {n:"The Moon",g:"☽",k:"Intuition · the unseen",r:"Not everything is clear yet, and that is okay. Trust your feelings while the fog lifts."},
    {n:"The Sun",g:"☀",k:"Joy · success",r:"Warmth and good news are close. Let yourself feel hopeful again."},
    {n:"Judgement",g:"❋",k:"Awakening · a calling",r:"Something is asking you to rise to it. You are ready for the next version of your life."},
    {n:"The World",g:"◉",k:"Completion · wholeness",r:"A cycle is coming full circle. Honor how far you have come before the next one begins."},
    {n:"The Tower",g:"⚡",k:"Sudden change · truth",r:"A shake-up clears away what was not built to last. What remains is real and yours."},
    {n:"The Devil",g:"⛓",k:"Attachment · release",r:"Notice what quietly holds you. You have more freedom here than it wants you to believe."}
  ];
  var HEAVY=/(suicide|kill myself|self.?harm|die|dying|death of|cancer|diagnos|pregnan|lawsuit|court|custody|medical|overdose)/i;
  var q=document.getElementById('pullQ'), btn=document.getElementById('pullBtn'),
      card=document.getElementById('pullCard'), res=document.getElementById('pullResult');
  if(!btn) return;
  function draw(){
    var question=(q.value||'').trim();
    if(HEAVY.test(question)){
      res.hidden=false;
      res.innerHTML='<p class="pull-name">A gentle pause</p><p class="pull-refl">That sounds heavy, and it deserves more than a card. This little tool is just for reflection. For something real and caring, please talk it through with Cherry, or reach a professional who can help.</p><a class="btn btn-primary" href="/shop.html">Book a reading with Cherry</a> <button class="btn btn-ghost" id="pullAgain2" type="button">Pull again</button>';
      document.getElementById('pullAgain2').onclick=reset; return;
    }
    var c=DECK[Math.floor(Math.random()*DECK.length)];
    card.classList.add('flipped');
    card.querySelector('.pc-glyph').textContent=c.g;
    setTimeout(function(){
      res.hidden=false;
      var lead=question? 'On what you asked, the card that came up is ' : 'Your card is ';
      res.innerHTML='<p class="eyebrow">Your card</p><p class="pull-name">'+c.n+'</p><p class="pull-keys">'+c.k+'</p><p class="pull-refl">'+lead+'<strong>'+c.n+'</strong>. '+c.r+'</p><p class="pull-note">For reflection only. A real reading with Cherry goes far beyond a single card.</p><div class="btn-row" style="justify-content:center"><a class="btn btn-primary" href="/shop.html">Book a real reading</a> <button class="btn btn-ghost" id="pullAgain" type="button">Pull another card</button></div>';
      document.getElementById('pullAgain').onclick=reset;
    },420);
  }
  function reset(){ card.classList.remove('flipped'); res.hidden=true; res.innerHTML=''; window.scrollTo({top:card.getBoundingClientRect().top+window.scrollY-140,behavior:'smooth'}); }
  btn.onclick=draw;
})();
